# example how to work with templates

- templates support
  - if
  - for loops
  - even nesting of for loops
  - syntax checking
  - embed the template into the binary

Its a very cool way how to do also do e.g. system administration, fill in 
config files, etc...

The example there is also a good demonstration of how to use json on a more 
complex object and read/write to file.
